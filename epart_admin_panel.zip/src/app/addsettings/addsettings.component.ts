import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsettings',
  templateUrl: './addsettings.component.html',
  styleUrls: ['./addsettings.component.scss']
})
export class AddsettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
