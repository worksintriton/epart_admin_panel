import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-banner',
  templateUrl: './cms-banner.component.html',
  styleUrls: ['./cms-banner.component.scss']
})
export class CmsBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
