import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-hero-section',
  templateUrl: './cms-hero-section.component.html',
  styleUrls: ['./cms-hero-section.component.scss']
})
export class CmsHeroSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
