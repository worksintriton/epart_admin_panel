import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-features',
  templateUrl: './cms-features.component.html',
  styleUrls: ['./cms-features.component.scss']
})
export class CmsFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
