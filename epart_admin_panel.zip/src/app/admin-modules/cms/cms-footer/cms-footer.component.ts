import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-footer',
  templateUrl: './cms-footer.component.html',
  styleUrls: ['./cms-footer.component.scss']
})
export class CmsFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
