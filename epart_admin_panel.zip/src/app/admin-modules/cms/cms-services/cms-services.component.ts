import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cms-services',
  templateUrl: './cms-services.component.html',
  styleUrls: ['./cms-services.component.scss']
})
export class CmsServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
