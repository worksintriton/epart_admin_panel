import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addseller',
  templateUrl: './addseller.component.html',
  styleUrls: ['./addseller.component.scss']
})
export class AddsellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
