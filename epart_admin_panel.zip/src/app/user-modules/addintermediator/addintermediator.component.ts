import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addintermediator',
  templateUrl: './addintermediator.component.html',
  styleUrls: ['./addintermediator.component.scss']
})
export class AddintermediatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
