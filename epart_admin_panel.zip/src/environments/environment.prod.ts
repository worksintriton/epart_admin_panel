export const environment = {
  production: true,
  baseurl:'http://localhost:3000/api/',
};
